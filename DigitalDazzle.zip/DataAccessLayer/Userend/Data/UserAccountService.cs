﻿

@code {
    public class UserAccountService
    {
        public ModelUserAccount? GetByUserName(string Email, string Password)
        {
            return DataAccessLayer.DalAuth.Auth(Email, Password);
        }
    }
}

