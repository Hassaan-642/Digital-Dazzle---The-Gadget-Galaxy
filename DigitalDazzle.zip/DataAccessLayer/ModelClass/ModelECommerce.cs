﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ModelClass;

namespace ModelClass
{
    public class ModelECommerce
    {
        
        public string? ImageURL { get; set; }
        public string? ProductName { get; set; }

        public string? Description { get; set; }

        public int PriceInUSD { get; set; }

        public int StockQuantity { get; set; }

        public int ProductId { get; set; }

     
        public string? FirstName { get; set; }

        public string? LastName { get; set;}

        public string? Email { get; set;}

        public string? Address { get; set;}

        public string? Password { get; set; }

        public string? Phone { get; set;}

        public string? Role { get; set; }

        public int UserId { get; set; }

        public string? feedback { get; set;}

        public string? name { get; set; }

        public string? EMAIL { get; set; }

        public string? logo { get; set; }



        public int orderId { get; set; }

        public string? email { get; set; }

        public string? password { get; set; }

        public int productQuantity { get; set; }

        public string? address { get; set; }

        public string? ContactNumber { get; set; }

        public string? PaymentMethod { get; set; }

        public bool IsEditing { get; set; }

        public string? warehouse { get; set; }

        public string? LocalStorage { get; set; }

        public string? deliever { get; set;}

        public int TrackId { get; set; }
    }
}
