﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Dbhelper
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection con = new SqlConnection("Data Source=HASSAAN\\SQLEXPRESS;Initial Catalog=VPLab;Integrated Security=True");
            return con;
        }
    }
}
