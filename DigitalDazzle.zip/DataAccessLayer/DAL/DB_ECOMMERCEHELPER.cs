﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DAL
{
    public class Db_ECOMMERCEHELPER

    {
        public static SqlConnection GetConnection()
        {
            SqlConnection conn = new SqlConnection("Data Source=Hassaan\\SQLEXPRESS;Initial Catalog=E_Commerce_DataBase;Integrated Security=True");
            return conn;
        }
    }

    
}
