﻿using ModelClass;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DAL
{
    public class E_Commerce_DataBase 
    {

        public static List<ModelECommerce> GetProductsData()
        {
            SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from ProductListings", conn);
            //we give the query in the left and passed the connection
            // the right
            SqlDataReader sqlDataReader1
             = cmd.ExecuteReader();
            List<ModelECommerce> ListProducts = new List<ModelECommerce>();
            while (sqlDataReader1.Read())
            {
                ModelECommerce product = new ModelECommerce();
                product.ImageURL = sqlDataReader1["ImageURL"].ToString();
                product.ProductName = sqlDataReader1["ProductName"].ToString();
                product.Description = sqlDataReader1["Description"].ToString();
                product.PriceInUSD = Convert.ToInt32(sqlDataReader1["PriceInUSD"]);
                product.StockQuantity = Convert.ToInt32(sqlDataReader1["StockQuantity"]);
                product.ProductId = Convert.ToInt32(sqlDataReader1["ProductId"]);
                
                ListProducts.Add(product);
            }
            conn.Close();
            return ListProducts;

        }
        public static List<ModelECommerce> GetUserData()
        {
            SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from UserAccount", conn);
            //we give the query in the left and passed the connection
            // the right
            SqlDataReader sqlDataReader2
             = cmd.ExecuteReader();
            List<ModelECommerce> ListUserData = new List<ModelECommerce>();
            while (sqlDataReader2.Read())
            {
                ModelECommerce UserData = new ModelECommerce();
                UserData.FirstName = sqlDataReader2["FirstName"].ToString();
                UserData.LastName = sqlDataReader2["LastName"].ToString();
                UserData.Email = sqlDataReader2["Email"].ToString();
                UserData.Password = sqlDataReader2["Password"].ToString();
                UserData.Address = sqlDataReader2["Address"].ToString();
                UserData.Phone = sqlDataReader2["Phone"].ToString();
                UserData.Role = sqlDataReader2["Role"].ToString() ;
                UserData.UserId = Convert.ToInt32(sqlDataReader2["UserId"]); 
                UserData.warehouse = sqlDataReader2["warehouse"].ToString();
                UserData.LocalStorage = sqlDataReader2["LocalStorage"].ToString();
                UserData.deliever = sqlDataReader2["deliever"].ToString();

                ListUserData.Add(UserData);
            }
            conn.Close();
            return ListUserData;

        }

        public static List<string> GetFirstName(int UserId)
        {
            SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT FirstName FROM UserAccount WHERE UserId = @UserId", conn);
            cmd.Parameters.AddWithValue("@UserId", UserId);

            SqlDataReader sqlDataReader = cmd.ExecuteReader();
            List<string> firstNames = new List<string>();

            while (sqlDataReader.Read())
            {
                string firstName = sqlDataReader["FirstName"].ToString();
                firstNames.Add(firstName);
            }

            conn.Close();
            return firstNames;
        }

        public static string GetUserInformationById(int UserId)
        {
            using (SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("GetUserFirstNameById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@UserId", UserId);

                    var FirstName = cmd.ExecuteScalar();

                    return FirstName != null ? FirstName.ToString() : null;
                }
            }
        }





        public static List<ModelECommerce> GetFeedBackData()
        {
            SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from FeedBack", conn);
            //we give the query in the left and passed the connection
            // the right
            SqlDataReader sqlDataReader2
             = cmd.ExecuteReader();
            List<ModelECommerce> ListFeedBackData = new List<ModelECommerce>();
            while (sqlDataReader2.Read())
            {
                ModelECommerce FeedBackData = new ModelECommerce();
                FeedBackData.feedback = sqlDataReader2["feedback"].ToString();
                FeedBackData.name = sqlDataReader2["name"].ToString();
                FeedBackData.email = sqlDataReader2["email"].ToString();

                ListFeedBackData.Add(FeedBackData);
            }
            conn.Close();
            return ListFeedBackData;

        }

        public static List<ModelECommerce> GetTrackData()
        {
            SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from TrackStatus", conn);
            //we give the query in the left and passed the connection
            // the right
            SqlDataReader sqlDataReader2
             = cmd.ExecuteReader();
            List<ModelECommerce> ListTrackData = new List<ModelECommerce>();
            while (sqlDataReader2.Read())
            {
                ModelECommerce TrackData = new ModelECommerce();
                TrackData.warehouse = sqlDataReader2["warehouse"].ToString();
                TrackData.LocalStorage = sqlDataReader2["LocalStorage"].ToString();
                TrackData.deliever = sqlDataReader2["deliever"].ToString();

                ListTrackData.Add(TrackData);
            }
            conn.Close();
            return ListTrackData;

        }

        public static void DeleteTrack(int TrackId)
        {
            using (SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection())
            {
                conn.Open();
                string query = "DELETE FROM TrackStatus WHERE TrackId = @TrackId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@TrackId", TrackId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void UpdateTrack(ModelECommerce updatedTrack)
        {
            using (SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection())
            {
                conn.Open();
                string query = @"
            UPDATE TrackStatus
            SET warehouse = @warehouse, LocalStorage = @LocalStorage, deliever = @deliever
            WHERE TrackId = @TrackId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@TrackId", updatedTrack.TrackId);
                    cmd.Parameters.AddWithValue("@warehouse", updatedTrack.warehouse);
                    cmd.Parameters.AddWithValue("@LocalStorage", updatedTrack.LocalStorage);
                    cmd.Parameters.AddWithValue("@deliever", updatedTrack.deliever);

                    cmd.ExecuteNonQuery();
                }
            }
        }


        public static List<ModelECommerce> GetLogoData()
        {
            SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from LogoOfWebsite", conn);
            //we give the query in the left and passed the connection
            // the right
            SqlDataReader sqlDataReader2
             = cmd.ExecuteReader();
            List<ModelECommerce> ListLogoData = new List<ModelECommerce>();
            while (sqlDataReader2.Read())
            {
                ModelECommerce LogoData = new ModelECommerce();
                LogoData.logo = sqlDataReader2["logo"].ToString();
                

                ListLogoData.Add(LogoData);
            }
            conn.Close();
            return ListLogoData;

        }

        public static List<ModelECommerce> GetOrderData()
        {
            SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from OrderDetails", conn);
            //we give the query in the left and passed the connection
            // the right
            SqlDataReader sqlDataReader2
             = cmd.ExecuteReader();
            List<ModelECommerce> ListOrderData = new List<ModelECommerce>();
            while (sqlDataReader2.Read())
            {
                ModelECommerce OrderData = new ModelECommerce();
                OrderData.orderId = Convert.ToInt32(sqlDataReader2["orderId"]);
                OrderData.email = sqlDataReader2["email"].ToString();
                OrderData.password = sqlDataReader2["password"].ToString();
                OrderData.productQuantity = Convert.ToInt32(sqlDataReader2["productQuantity"]);
                OrderData.address = sqlDataReader2["address"].ToString();
                OrderData.ContactNumber = sqlDataReader2["ContactNumber"].ToString();
                OrderData.PaymentMethod = sqlDataReader2["PaymentMethod"].ToString();
               // OrderData.IsEditing = Convert.ToBoolean(sqlDataReader2["IsEditing"]);
                OrderData.IsEditing = !Convert.IsDBNull(sqlDataReader2["IsEditing"]) && Convert.ToBoolean(sqlDataReader2["IsEditing"]);



                ListOrderData.Add(OrderData);
            }
            conn.Close();
            return ListOrderData;

        }

        public static void DeleteUser(int UserId)
        {
            using (SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection())
            {
                conn.Open();
                string query = "DELETE FROM UserAccount WHERE UserId = @UserId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void DeleteOrder(int orderId)
        {
            using (SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection())
            {
                conn.Open();
                string query = "DELETE FROM OrderDetails WHERE orderId = @orderId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@orderId", orderId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void UpdateUser(ModelECommerce updatedUser)
        {
            using (SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection())
            {
                conn.Open();
                string query = @"
            UPDATE UserAccount
            SET FirstName = @FirstName, LastName = @LastName, Email = @Email,
                Password = @Password, Address = @Address, Phone = @Phone, warehouse=@warehouse, LocalStorage=@LocalStorage, deliever=@deliever
            WHERE UserId = @UserId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", updatedUser.UserId);
                    cmd.Parameters.AddWithValue("@FirstName", updatedUser.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", updatedUser.LastName);
                    cmd.Parameters.AddWithValue("@Email", updatedUser.Email);
                    cmd.Parameters.AddWithValue("@Password", updatedUser.Password);
                    cmd.Parameters.AddWithValue("@Address", updatedUser.Address);
                    cmd.Parameters.AddWithValue("@Phone", updatedUser.Phone);
                    cmd.Parameters.AddWithValue("@warehouse", updatedUser.warehouse);
                    cmd.Parameters.AddWithValue("@LocalStorage", updatedUser.LocalStorage);
                    cmd.Parameters.AddWithValue("@deliever", updatedUser.deliever);


                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void UpdateOrder(ModelECommerce updatedOrder)
        {
            using (SqlConnection conn = Db_ECOMMERCEHELPER.GetConnection())
            {
                conn.Open();
                string query = @"
            UPDATE OrderDetails
            SET email = @email, password = @password,
                productQuantity = @productQuantity, address = @address,
                ContactNumber = @ContactNumber, PaymentMethod = @PaymentMethod
            WHERE orderId = @orderId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@orderId", updatedOrder.orderId);
                    cmd.Parameters.AddWithValue("@email", updatedOrder.email);
                    cmd.Parameters.AddWithValue("@password", updatedOrder.password);
                    cmd.Parameters.AddWithValue("@ProductQuantity", updatedOrder.productQuantity);
                    cmd.Parameters.AddWithValue("@Address", updatedOrder.address);
                    cmd.Parameters.AddWithValue("@ContactNumber", updatedOrder.ContactNumber);
                    cmd.Parameters.AddWithValue("@PaymentMethod", updatedOrder.PaymentMethod);

                    cmd.ExecuteNonQuery();
                }
            }
        }


    }
}
    


