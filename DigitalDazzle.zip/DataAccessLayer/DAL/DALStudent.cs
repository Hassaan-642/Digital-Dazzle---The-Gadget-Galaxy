﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ModelClass;

namespace DAL
{
    public class DALStudent
    {

        public static List<ModelStudent> GetStudentsData()
        {
            SqlConnection con = Dbhelper.GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from DALStudent", con);
            //we give the query in the left and passed the connection
            // the right
            SqlDataReader sqlDataReader = cmd.ExecuteReader();
            List<ModelStudent> ListStudents = new List<ModelStudent>();
            while(sqlDataReader.Read())
            {
                ModelStudent student = new ModelStudent();
                student.id = Convert.ToInt32(sqlDataReader["id"]);
                student.name = sqlDataReader["name"].ToString();
                student.email = sqlDataReader["email"].ToString();
                ListStudents.Add(student);
            }
            con.Close();
            return ListStudents;

        }
    }
}

